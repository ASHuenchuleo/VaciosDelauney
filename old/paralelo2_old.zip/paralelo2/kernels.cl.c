#include "consts.h"
#include "triang.cl.c"




/* initialize_values
 * 
 * Inicializa los valores de is_seed y visited.
 * */

kernel void initialize_values(global int *is_seed, global int *visited,
															global int *parent,
															global int *ordering)
{
	int i;
	
	i = get_global_id(0);
	
	is_seed[i] = FALSE;
	visited[i] = FALSE;
	parent[i] = NO_ADJ;
	ordering[i] = i;
}



/* mark_max_max
 * 
 * Marca las aristas máx-máx.
 * */

kernel void mark_max_max(global double *r, global int *p, global int *max)
{
	int i;
	
	i = get_global_id(0);
	max[i] = max_edge_index(i, r, p);
}



/* mark_disconnections
 * 
 * Marca los arcos asociados a aristas nomáx-nomáx.
 * */

kernel void mark_disconnections(global int *p, global int *adj, global int *max,
																global int *disconnect)
{
	int i;
	
	i = get_global_id(0);
	
	disconnect[3*i + 0] = (adj[3*i + 0] != TRIANG_BORDER) && is_nomax_nomax(i, adj[3*i + 0], p, max);
	disconnect[3*i + 1] = (adj[3*i + 1] != TRIANG_BORDER) && is_nomax_nomax(i, adj[3*i + 1], p, max);
	disconnect[3*i + 2] = (adj[3*i + 2] != TRIANG_BORDER) && is_nomax_nomax(i, adj[3*i + 2], p, max);
}

void process_edge(int i, int edge_index, global int *p, global int* adj, global int* max, global int* parent, global int* is_seed){
	int ii;
	int ij;
	int j;
	j = adj[3*i + edge_index];
	if(j != TRIANG_BORDER){
		get_common_edge(i, j, &ii, &ij, p);
		int edge_is_max_max = ij == max[j] && ii == max[i];
		is_seed[i] = (edge_is_max_max && j > i) || is_seed[i];
		/* If the edge must not be removed */
		if(!(ii != max[i]) || (edge_is_max_max && j < i)){
			parent[i] = j;
		}
	}
}

/* mark_disconnections
 * 
 * Marca los arcos asociados a aristas nomáx-nomáx.
 * */

kernel void mark_disconnections_tree(global int *p, global int *adj, global int *max,
																global int *is_seed, global int *parent)
{
	int i;
	
	i = get_global_id(0);


	/* If must disconnect */
	process_edge(i, 0, p, adj, max, parent, is_seed);
	process_edge(i, 1, p, adj, max, parent, is_seed);
	process_edge(i, 2, p, adj, max, parent, is_seed);
	if(is_seed[i]){
		parent[i] = i;
	}

}

/* jump_to_root
* Hace el pointer jumping desde los nodos a la raiz
*/
kernel void jump_to_root(global int *parent, global int *root_id, global double* area, int jumping_max_steps){
	int i = get_global_id(0);
	int j = parent[i];
	int step_count;
	for(step_count = 0; step_count < jumping_max_steps; step_count++){
		if(j != NO_ADJ){
			if(parent[j] != NO_ADJ){
				root_id[i] = j;
				parent[i] = parent[j];
			}
		}
	}
}



/* disconnect
 * 
 * Desconecta los arcos del grafo de adyacencia, marcados para el efecto.
 * */

kernel void disconnect(global int *adj, global int *disconnect)
{
	int i;
	
	i = get_global_id(0);
	
	if(disconnect[3*i + 0] == TRUE)
	{
		adj[3*i + 0] = NO_ADJ;
	}
	
	if(disconnect[3*i + 1] == TRUE)
	{
		adj[3*i + 1] = NO_ADJ;
	}
	
	if(disconnect[3*i + 2] == TRUE)
	{
		adj[3*i + 2] = NO_ADJ;
	}
}



/* mark_seeds
 * 
 * Marca los triángulos que son semilla.
 * */

kernel void mark_seeds(global int *p, global int *adj,
												global int *max, global int *is_seed)
{
	int i;
	
	i = get_global_id(0);
	is_seed[i] = ((adj[3*i + 0] != NO_ADJ) && (adj[3*i + 0] != TRIANG_BORDER) &&
			is_max_max(i, adj[3*i + 0], p, max) && (adj[3*i + 0] < i))
			||
			((adj[3*i + 1] != NO_ADJ) && (adj[3*i + 1] != TRIANG_BORDER) &&
			is_max_max(i, adj[3*i + 1], p, max) && (adj[3*i + 1] < i))
			||
			((adj[3*i + 2] != NO_ADJ) && (adj[3*i + 2] != TRIANG_BORDER) &&
			is_max_max(i, adj[3*i + 2], p, max) && (adj[3*i + 2] < i));
}



/* communicate_types_areas
 * 
 * Comunica a cada triángulo el área total y tipo de región contenido en su
 * nodo raíz.
 * */

kernel void communicate_types_areas(global int *type, global double *area,
																		global int *root_id)
{
	int i;
	
	i = get_global_id(0);
	
	area[i] = area[root_id[i]];
	type[i] = type[root_id[i]];
}
