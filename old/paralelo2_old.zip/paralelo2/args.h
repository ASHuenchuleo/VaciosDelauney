/* Prototipos de funciones para manejar argumentos de línea de comando. */

extern void read_arguments(int argc, char **argv, char **ppath, double *threshold,
														char **cpath_prefix);
